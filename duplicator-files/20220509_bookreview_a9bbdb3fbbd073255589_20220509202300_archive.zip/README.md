# book-review
This is for adding books information from fronted

#Creating Custom Books Plugin
#Custom Post type is Books
#Ajax Adding Book Review Form into specific post type of books 
#Using latest vesrion of wordpress 
#DB File is in DB folder
#setup menually extract
or here another folder to setup up site using duplicator plugin

#Backend Admin Access
username: admin
password: book-review12#